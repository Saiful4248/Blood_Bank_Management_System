<?php

$server ="localhost";
$user = "root";
$pass ="";
$dbname ="bloodbank";

$conn = mysqli_connect($server,$user,$pass,$dbname);



?>